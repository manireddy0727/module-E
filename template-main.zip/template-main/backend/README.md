# sys-coos backend

* Uses `ssh2-sftp-client` npm package for uploading to `sftp` server
